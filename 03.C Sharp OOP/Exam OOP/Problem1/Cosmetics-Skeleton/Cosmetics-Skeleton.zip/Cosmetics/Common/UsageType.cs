﻿namespace Cosmetics.Common
{
    public enum UsageType
    {
        EveryDay,
        Medical
    }
}
